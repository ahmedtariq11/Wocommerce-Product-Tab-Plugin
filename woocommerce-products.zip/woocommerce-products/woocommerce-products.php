<?php

/*
    Plugin Name: Woocommerce products
    Plugin URI: http://www.enovathemes.com
    Description: Better product grouping presentation for your WooCommerce shop
    Author: Enovathemes
    Version: 1.0
    Author URI: http://enovathemes.com
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/*
    1. Enqueue/register styles and scripts
    2. Create tab shortcode
    3. Create product shortcode
*/

// Enqueue/register styles and scripts
function plugin_scripts_styles(){

    wp_enqueue_style( 'style', plugins_url('/css/style.css', __FILE__ ), array(), '1.0.0' );

    // Required Plugins
    wp_enqueue_script( 'imagesloaded');
    wp_enqueue_script( 'owl-carousel', plugins_url('/js/owl.carousel.js', __FILE__ ), array('jquery'), '', true);
    // Main js file
	wp_enqueue_script( 'main', plugins_url('/js/main.js', __FILE__ ), array('jquery'), '', true);
}
add_action( 'wp_enqueue_scripts', 'plugin_scripts_styles' );


// Create tab shortcode
function et_tab($atts, $content = null) {

	extract(shortcode_atts(array(), $atts));

	$output = '';

	static $id_counter = 1;

	$class   = array();
	$class[] = 'et-tab';
	$class[] = 'et-clearfix';

	$output .='<div id="et-tab-'.$id_counter.'" class="'.implode(" ", $class).'">';
		$output .= do_shortcode($content);
	$output .= '</div>';

	$id_counter++;

	return $output;

}
add_shortcode('et_tab', 'et_tab');

function et_tab_item($atts, $content = null) {

	extract(shortcode_atts(array(
		'title'  => '',
		'active' => 'false',
	), $atts));

	$output = '';

	static $id_counter = 1;

    $class   = array();
	$class[] = 'tab-item';
    $class[] = 'et-clearfix';
	$class[] = 'active-'.esc_attr($active);

	$output .= '<div data-target="tab-'. sanitize_title( $title ) .'" class="'.implode(' ',$class).'">';
		if (isset($title) && !empty($title)) {
			$output .= esc_attr($title);
		}
	$output .= '</div> ';
	$output .= '<div id="tab-'.sanitize_title($title).'-'.$id_counter.'" class="tab-content et-clearfix">';
	    $output .= do_shortcode($content);
	$output .= '</div>';

	$id_counter++;

	return $output;
}
add_shortcode('et_tab_item', 'et_tab_item');

// Create product shortcode

function et_products($atts, $content = null) {
    extract(shortcode_atts(
        array(
            'layout' 		        => 'grid',  // grid OR carousel
            'autoplay'              => 'false', // true OR false
            'columns' 		        => '1', // 1 | 2 | 3 | 4
            'rows'                  => '1',     // 1 | 2 | 3 | 4 - carousel only
            'quantity' 		        => '12',
            'type' 			        => 'recent', // recent | featured | sale | best_selling
        ), $atts)
    );

    static $id_counter = 1;

    if (class_exists('Woocommerce')) {

        $output = '';

        global $post;

        $query_options = array(
            'post_type'           => 'product',
            'post_status'         => 'publish',
            'meta_query'          => WC()->query->get_meta_query(),
            'tax_query'           => WC()->query->get_tax_query(),
            'ignore_sticky_posts' => 1,
            'posts_per_page' 	  => absint($quantity),
        );

        if ($type == "featured"){
			$query_options = array(
				'post_type'           => 'product',
				'post_status'         => 'publish',
				'meta_query'          => WC()->query->get_meta_query(),
				'ignore_sticky_posts' => 1,
				'posts_per_page' 	  => absint($quantity),
				'tax_query'           => array(
					array(
						'taxonomy' => 'product_visibility',
						'field'    => 'name',
						'terms'    => 'featured',
						'operator' => 'IN',
					)
				),
			);
		}

        if ($type == "sale"){
			$query_options = array(
				'post_type'           => 'product',
				'post_status'         => 'publish',
				'meta_query'          => WC()->query->get_meta_query(),
				'ignore_sticky_posts' => 1,
				'posts_per_page' 	  => absint($quantity),
				'post__in'            => array_merge( array( 0 ), wc_get_product_ids_on_sale() ),
			);
		}

		if ($type == "best_selling"){

			$query_options = array(
				'post_type'           => 'product',
				'post_status'         => 'publish',
				'meta_query'          => WC()->query->get_meta_query(),
				'tax_query'           => WC()->query->get_tax_query(),
				'ignore_sticky_posts' => 1,
				'posts_per_page' 	  => absint($quantity),
				'orderby'             => 'meta_value_num',
				'meta_key'            => 'total_sales',
			);
		}

        $products = new WP_Query($query_options);

        if($products->have_posts()){

            $counter    = 1;

            $class      = array();
            $attributes = array();

            $class[] = 'products';
            $class[] = esc_attr($layout);

            if ($layout == 'carousel') {
                $class[] = 'owl-carousel';
            }

            $attributes[] = 'data-columns="'.esc_attr($columns).'"';
            $attributes[] = 'data-autoplay="'.esc_attr($autoplay).'"';

            $output .= '<ul class="'.esc_attr(implode(' ', $class)).'" '.implode(' ', $attributes).'>';

                while ($products->have_posts() ) {

                    $products->the_post();

                    global $product;

                    if ($layout == "carousel" && $rows != 1) {

                        $product_wrapper_start = '';
                        $product_wrapper_end   = '';

                        if (($counter % 2 == 1 && $rows == 2) || ($counter % 3 == 1 && $rows == 3) || ($counter % 4 == 1 && $rows == 4)){
                            $product_wrapper_start = '<li class="product-wrapper">';
                        }

                        if (($counter % 2 == 0 && $rows == 2) || ($counter % 3 == 0 && $rows == 3) || ($counter % 4 == 0 && $rows == 4)){
                            $product_wrapper_end   = '</li>';
                        }

                        $output .= $product_wrapper_start;
                            $output .= '<div class="product" id="product-'.esc_attr($product->get_id()).'">';
                                ob_start();
                                    do_action( 'woocommerce_before_shop_loop_item' );
                                    do_action( 'woocommerce_before_shop_loop_item_title' );
                                    do_action( 'woocommerce_shop_loop_item_title' );
                                    do_action( 'woocommerce_after_shop_loop_item_title' );
                                    do_action( 'woocommerce_after_shop_loop_item' );
                                $output .= ob_get_clean();
                            $output .= '</div>';
                        $output .= $product_wrapper_end;

                        $counter++;

                    } else {
                        $output .= '<li class="product" id="product-'.esc_attr($product->get_id()).'">';
                            ob_start();
                                do_action( 'woocommerce_before_shop_loop_item' );
                                do_action( 'woocommerce_before_shop_loop_item_title' );
                                do_action( 'woocommerce_shop_loop_item_title' );
                                do_action( 'woocommerce_after_shop_loop_item_title' );
                                do_action( 'woocommerce_after_shop_loop_item' );
                            $output .= ob_get_clean();
                        $output .= '</li>';
                    }

                }

                wp_reset_postdata();

            $output .= '</ul>';

            $id_counter++;

            return $output;

        }

    } else {
        echo "Please install/activate Woocommerce plugin";
    }
}
add_shortcode('et_products', 'et_products');
?>
