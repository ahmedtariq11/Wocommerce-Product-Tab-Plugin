/* Tabs
---------------*/

    function refreshCarousel(tab){
        tab.find('.products').each(function(){
            jQuery(this).trigger('refresh.owl.carousel');
        });
    }

	(function($){

		"use strict";

		$('.et-tab').each(function(){

			var $this    = $(this),
				tabs     = $this.find('.tab-item'),
				tabsQ    = tabs.length,
				tabsContent = $this.find('.tab-content');

			tabs.wrapAll('<div class="tabset et-clearfix"></div>');
			tabsContent.wrapAll('<div class="tabs-container et-clearfix"></div>');

			var tabSet = $this.find('.tabset');

				if(!tabs.hasClass('active')){
					tabs.first().addClass('active');
				}

				tabs.each(function(){

					var $thiz = $(this);

					if ($thiz.hasClass('active')) {
						$thiz.siblings()
						.removeClass("active");
						tabsContent.hide(0).removeClass('active');
						tabsContent.eq($thiz.index()).show(0).addClass('active');
					}
				});

				if(tabsQ >= 2){

					tabs.on('click', function(){
						var $self = $(this);

						if(!$self.hasClass("active")){

							$self.addClass("active");

							$self.siblings()
							.removeClass("active");

							tabsContent.hide(0).removeClass('active');
							tabsContent.eq($self.index()).show(0).addClass('active');
                            refreshCarousel(tabsContent.eq($self.index()));
						}

					});
				}

		});


        // Initialize carousel for the first load

        $('.products.carousel').each(function(){

			var $this = $(this);
            $this.imagesLoaded(function(){
                $this.owlCarousel({
                        margin:24,
                        nav:true,
    				    autoplay:$this.data('autoplay'),
    					items:$this.data('columns'),
    				    responsive:{
    				    	320 : {items:1},
    				    	768 : {items:2},
    				    	1024 : {items:3},
    				    	1280 : {items:$this.data('columns')}
    				    },
    				});
            });

		});


	})(jQuery);
